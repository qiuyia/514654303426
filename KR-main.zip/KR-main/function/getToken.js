﻿const $ = new Env('getToken');
var __encode ='jsjiami.com',_a={}, _0xb483=["\x5F\x64\x65\x63\x6F\x64\x65","\x68\x74\x74\x70\x3A\x2F\x2F\x77\x77\x77\x2E\x73\x6F\x6A\x73\x6F\x6E\x2E\x63\x6F\x6D\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x6F\x62\x66\x75\x73\x63\x61\x74\x6F\x72\x2E\x68\x74\x6D\x6C"];(function(_0xd642x1){_0xd642x1[_0xb483[0]]= _0xb483[1]})(_a);var __Oxe874c=["\x6A\x73\x6A\x69\x61\x6D\x69\x2E\x63\x6F\x6D\x2E\x76\x36","\u202E\x4F\uFF2F\x30\x24","\x46\x45\x78\x67\x5A\x51\x3D\x3D","\x77\x70\x39\x6B\x4B\x4D\x4F\x65","\x53\x73\x4B\x79\x77\x71\x48\x43\x74\x67\x3D\x3D","\x77\x71\x4E\x42\x46\x63\x4F\x34\x45\x63\x4B\x77\x77\x35\x66\x44\x6C\x4D\x4B\x31","\x4A\x33\x56\x6C\x66\x4D\x4F\x70\x59\x73\x4B\x33\x52\x42\x77\x3D","\x46\x51\x58\x44\x76\x4D\x4B\x4F","\x49\x73\x4B\x6F\x64\x73\x4F\x66","\x49\x48\x48\x44\x6A\x6B\x59\x3D","\x41\x63\x4F\x33\x58\x67\x3D\x3D","\x36\x49\x79\x67\x35\x59\x79\x4F\x35\x36\x36\x68\x35\x5A\x47\x65\x35\x61\x65\x48\x36\x4C\x61\x61\x37\x37\x32\x31\x36\x4B\x32\x67\x35\x71\x47\x39\x35\x70\x2B\x56\x35\x70\x32\x51\x35\x59\x6D\x6D\x35\x34\x6D\x77\x35\x6F\x4F\x32\x4D\x51\x3D\x3D","\x77\x34\x62\x43\x6C\x38\x4B\x51\x41\x67\x3D\x3D","\x61\x6C\x72\x43\x71\x51\x67\x3D","\x77\x70\x6A\x44\x75\x77\x44\x43\x75\x51\x3D\x3D","\x77\x70\x45\x4C\x50\x48\x63\x3D","\x77\x70\x39\x71\x77\x37\x6E\x43\x6C\x77\x3D\x3D","\x49\x54\x31\x56\x45\x63\x4B\x6A\x77\x37\x4A\x38\x46\x73\x4B\x52","\x4D\x54\x50\x43\x6D\x6E\x6F\x3D","\x77\x6F\x58\x43\x6F\x43\x2F\x43\x6D\x77\x3D\x3D","\x77\x71\x37\x44\x74\x67\x2F\x43\x6E\x51\x3D\x3D","\x64\x73\x4B\x55\x77\x6F\x6E\x43\x69\x51\x3D\x3D","\x59\x47\x45\x2F\x59\x41\x3D\x3D","\x77\x72\x5A\x53\x77\x37\x4D\x3D","\x77\x6F\x50\x43\x71\x54\x72\x43\x71\x77\x3D\x3D","\x77\x70\x77\x50\x77\x36\x30\x69","\x77\x71\x55\x6D\x58\x63\x4F\x4C","\x77\x36\x37\x44\x6A\x73\x4F\x6B\x77\x71\x6F\x3D","\x4A\x6B\x48\x44\x6F\x31\x6B\x3D","\x43\x58\x44\x43\x6F\x33\x70\x76\x77\x6F\x6E\x43\x6B\x73\x4F\x62\x46\x57\x59\x64\x77\x34\x4C\x43\x6F\x67\x3D\x3D","\x77\x70\x78\x77\x77\x36\x30\x38\x57\x41\x3D\x3D","\x77\x70\x6A\x44\x70\x52\x37\x43\x75\x51\x49\x3D","\x77\x34\x72\x44\x75\x73\x4B\x78\x77\x6F\x76\x44\x74\x47\x6A\x44\x76\x4D\x4F\x7A\x56\x38\x4B\x33","\x77\x71\x7A\x43\x6C\x63\x4F\x6F\x61\x44\x4E\x68\x77\x70\x50\x43\x6C\x73\x4F\x75\x48\x6C\x39\x5A\x77\x70\x6A\x43\x6C\x77\x3D\x3D","\x57\x73\x4F\x54\x46\x38\x4B\x35\x77\x72\x38\x3D","\x63\x52\x50\x44\x6E\x6B\x45\x3D","\x61\x6C\x72\x43\x74\x78\x59\x3D","\x53\x73\x4B\x79\x77\x71\x48\x43\x71\x4D\x4F\x70","\x4A\x42\x74\x70\x4D\x6C\x4D\x3D","\x52\x77\x51\x37\x77\x36\x72\x44\x6C\x41\x3D\x3D","\x49\x73\x4F\x4A\x64\x73\x4F\x66\x53\x41\x3D\x3D","\x4D\x73\x4B\x4E\x77\x72\x4D\x3D","\x77\x37\x66\x44\x68\x6E\x6A\x43\x72\x67\x3D\x3D","\x77\x72\x66\x43\x67\x42\x72\x44\x6A\x67\x3D\x3D","\x55\x33\x62\x44\x73\x4D\x4B\x34\x77\x35\x77\x3D","\x47\x63\x4F\x33\x55\x73\x4F\x72\x46\x67\x3D\x3D","\x49\x47\x35\x38\x63\x4D\x4F\x70","\x4A\x6B\x48\x44\x6F\x31\x6E\x44\x67\x67\x3D\x3D","\x42\x56\x42\x59\x52\x4D\x4F\x57","\x41\x78\x68\x6F\x4B\x63\x4B\x63","\x77\x72\x78\x61\x41\x41\x3D\x3D","\x77\x37\x48\x43\x6E\x6B\x7A\x43\x6B\x68\x30\x3D","\x77\x6F\x38\x56\x50\x48\x63\x3D","\x77\x70\x76\x43\x6F\x45\x37\x43\x6D\x33\x55\x3D","\x50\x4D\x4F\x4A\x64\x73\x4F\x66\x4E\x77\x3D\x3D","\x45\x63\x4B\x7A\x77\x36\x52\x63","\x77\x71\x58\x43\x6C\x4D\x4B\x69\x54\x67\x3D\x3D","\x45\x55\x70\x43\x77\x70\x59\x3D","\x77\x35\x5A\x49\x77\x35\x67\x3D","\x52\x32\x55\x6C\x77\x36\x6F\x3D","\x77\x34\x35\x49\x77\x35\x54\x43\x72\x41\x34\x3D","\x62\x6D\x45\x38","\x35\x4C\x71\x4A\x35\x4C\x69\x58\x36\x4C\x79\x73\x35\x5A\x71\x48\x35\x4C\x71\x46\x35\x36\x75\x35\x35\x70\x53\x50\x35\x6F\x32\x51","\x57\x73\x4F\x4E\x43\x63\x4F\x47","\x77\x37\x48\x44\x76\x7A\x50\x44\x72\x57\x49\x3D","\x65\x63\x4F\x7A\x49\x51\x3D\x3D","\x4A\x38\x4F\x63\x5A\x73\x4F\x64\x4D\x53\x4C\x43\x74\x38\x4F\x4C\x53\x63\x4F\x4A\x77\x36\x6B\x3D","\x43\x44\x74\x42\x77\x70\x2F\x43\x6C\x6E\x68\x38\x77\x34\x73\x76\x58\x4D\x4F\x6C\x77\x6F\x42\x5A\x4B\x43\x6A\x43\x6D\x43\x5A\x63\x77\x36\x64\x6F\x56\x31\x2F\x43\x6D\x69\x67\x46\x77\x34\x77\x67\x42\x7A\x6E\x43\x73\x4D\x4B\x34","\x38\x59\x71\x5A\x68\x46\x37\x44\x6A\x46\x38\x4C\x77\x70\x44\x43\x6F\x38\x4F\x72\x51\x46\x42\x34\x77\x36\x49\x2F\x36\x4B\x32\x52\x35\x72\x43\x4C\x35\x61\x65\x53\x36\x4C\x53\x7A\x37\x37\x2B\x6B\x36\x4B\x36\x58\x35\x71\x4F\x2B\x35\x70\x32\x52\x35\x37\x79\x6F\x36\x4C\x65\x38\x36\x59\x53\x37\x36\x4B\x36\x4C","\x36\x49\x32\x68\x35\x59\x79\x72\x35\x36\x36\x37\x35\x5A\x43\x74\x35\x61\x57\x6A\x36\x4C\x53\x71\x37\x37\x2B\x73\x36\x4B\x32\x4D\x35\x71\x47\x74\x35\x70\x36\x31\x35\x70\x32\x70\x35\x59\x71\x4A\x35\x34\x69\x54\x35\x6F\x4B\x6E\x45\x67\x3D\x3D","\x59\x4D\x4F\x36\x47\x4D\x4B\x67","\x4D\x55\x7A\x44\x70\x58\x6F\x3D","\x4B\x53\x35\x73\x77\x71\x51\x3D","\x77\x70\x39\x71\x77\x70\x6A\x44\x71\x41\x3D\x3D","\x35\x4C\x6D\x67\x35\x4C\x71\x46\x36\x4C\x36\x2F\x35\x5A\x69\x36\x35\x4C\x71\x50\x35\x36\x6D\x63\x35\x70\x65\x6B\x35\x6F\x36\x6B","\x77\x71\x4C\x44\x70\x63\x4B\x65\x77\x72\x6F\x3D","\x77\x36\x2F\x44\x76\x7A\x50\x43\x6B\x67\x3D\x3D","\x45\x42\x55\x6F\x77\x6F\x58\x43\x75\x63\x4F\x4A\x43\x51\x37\x43\x6C\x38\x4F\x43\x55\x63\x4F\x4F\x43\x63\x4B\x47\x49\x47\x39\x35\x77\x34\x2F\x43\x6F\x73\x4F\x35\x77\x34\x2F\x44\x68\x68\x6C\x44\x77\x70\x7A\x44\x6A\x38\x4B\x4E\x77\x72\x6B\x4C\x77\x70\x6E\x44\x72\x69\x35\x44\x77\x37\x49\x56\x45\x38\x4B\x6E\x77\x71\x54\x44\x71\x7A\x4C\x43\x74\x73\x4B\x45\x52\x4D\x4B\x77\x56\x63\x4F\x62\x77\x35\x44\x43\x6D\x63\x4F\x55\x77\x37\x42\x58\x77\x37\x39\x36\x77\x35\x37\x43\x69\x63\x4F\x35\x77\x36\x55\x46\x77\x37\x55\x3D","\x4F\x79\x54\x43\x76\x4D\x4F\x53\x43\x73\x4F\x67\x48\x63\x4F\x52\x59\x38\x4B\x36\x77\x34\x4D\x78\x77\x37\x4D\x6B\x77\x72\x4C\x44\x6D\x63\x4B\x47\x77\x6F\x6A\x43\x75\x46\x50\x43\x76\x73\x4B\x32\x77\x35\x44\x43\x71\x63\x4F\x56\x77\x70\x44\x44\x74\x38\x4B\x64\x77\x70\x64\x6E\x77\x37\x70\x78\x77\x35\x51\x3D","\x77\x6F\x72\x44\x6F\x43\x6B\x3D","\x5A\x63\x4B\x4F\x48\x4D\x4B\x59\x77\x36\x72\x43\x72\x52\x66\x43\x72\x58\x6F\x6D\x77\x34\x41\x72\x56\x43\x48\x43\x6A\x73\x4F\x48\x44\x63\x4B\x63\x43\x56\x2F\x43\x68\x38\x4B\x4C\x59\x38\x4B\x46\x64\x52\x41\x2F\x55\x63\x4F\x4F\x4B\x7A\x66\x44\x6C\x63\x4B\x4F\x51\x38\x4F\x36\x77\x34\x63\x63\x77\x70\x48\x43\x72\x38\x4F\x50\x4D\x63\x4B\x56\x52\x73\x4B\x56\x77\x72\x46\x57\x57\x41\x3D\x3D","\x4D\x33\x74\x2B\x5A\x63\x4B\x72\x4A\x63\x4B\x36\x52\x77\x4D\x4A\x58\x73\x4F\x41\x55\x30\x5A\x76\x4B\x6D\x67\x3D","\x55\x44\x50\x44\x6F\x6E\x6F\x3D","\x77\x35\x6A\x43\x6C\x38\x4F\x76\x48\x41\x3D\x3D","\x77\x71\x56\x32\x4B\x63\x4B\x79","\x4E\x63\x4B\x63\x4B\x46\x59\x3D","\x77\x36\x37\x43\x72\x38\x4B\x62\x77\x34\x73\x3D","\x6A\x53\x73\x6C\x78\x68\x52\x47\x6A\x45\x55\x69\x61\x66\x54\x6E\x43\x6B\x6D\x44\x69\x2E\x63\x6F\x6D\x2E\x76\x36\x3D\x3D","\x70\x6F","\x73\x68\x69\x66\x74","\x70\x75\x73\x68","\u202E","\x6C\x65\x6E\x67\x74\x68","\x70","","\x72\x65\x70\x6C\x61\x63\x65","\x73\x6C\x69\x63\x65","\x63\x6F\x6E\x63\x61\x74","\x30\x78","\x51\x51\x51\x30\x51","\x75\x6E\x64\x65\x66\x69\x6E\x65\x64","\x6F\x62\x6A\x65\x63\x74","\x66\x75\x6E\x63\x74\x69\x6F\x6E","\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5A\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2B\x2F\x3D","\x61\x74\x6F\x62","\x63\x68\x61\x72\x41\x74","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x69\x6E\x64\x65\x78\x4F\x66","\x25","\x30\x30","\x74\x6F\x53\x74\x72\x69\x6E\x67","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x51\x4F\x51\x4F\x4F","\x51\x4F\x30\x4F\x30","\x51\x51\x51\x51\x51","\u202B\x30","\x48\x33\x30\x65","\x65\x6E\x76","\u202E\x31","\x48\x55\x6A\x41","\u202B\x32","\x40\x28\x74\x50","\u202E\x33","\x6E\x78\x70\x24","\u202B\x34","\x4A\x6E\x24\x64","\x51\x51\x30\x30","\x51\x51\x51\x4F","\u202B\x35","\x57\x6A\x57\x4D","\u202E\x36","\x43\x35\x5B\x53","\x51\x51\x30\x4F","\u202B\x37","\x51\x5E\x45\x30","\x51\x30\x51\x30","\u202E\x38","\x46\x48\x6C\x45","\u202B\x39","\x4B\x28\x7A\x6E","\x4F\x4F\x30\x51","\u202B\x61","\x53\x71\x24\x6D","\u202E\x62","\u202E\x63","\x69\x26\x7A\x77","\u202B\x64","\u202B\x65","\u202E\x66","\x4F\x23\x30\x61","\u202B\x31\x30","\x29\x72\x28\x47","\u202B\x31\x31","\x43\x33\x52\x41","\x4F\x4F\x51\x4F","\u202E\x31\x32","\x68\x32\x68\x73","\x4F\x4F\x4F\x4F","\u202E\x31\x33","\x59\x7A\x58\x63","\u202E\x31\x34","\x37\x45\x61\x6A","\u202B\x31\x35","\x62\x31\x49\x43","\u202B\x31\x36","\x23\x26\x6D\x21","\u202E\x31\x37","\x65\x65\x48\x52","\u202B\x31\x38","\u202E\x31\x39","\x61\x70\x70\x6C\x69\x63\x61\x74\x69\x6F\x6E\x2F\x6A\x73\x6F\x6E","\u202B\x31\x62","\u202B\x31\x63","\x34\x78\x37\x62","\u202E\x31\x61","\u202E\x31\x65","\u202E\x31\x64","\u202E\x31\x66","\u202B\x32\x31","\x4B\x62\x33\x67","\u202B\x32\x32","\x26\x67\x53\x76","\u202B\x32\x30","\x65\x4A\x51\x40","\u202B\x32\x34","\x26\x64\x34\x67","\u202B\x32\x33","\x6C\x6F\x67","\x51\x51\x51\x30","\x6C\x6F\x67\x45\x72\x72","\x70\x61\x72\x73\x65","\u202E\x32\x36","\u202B\x32\x35","\u202B\x32\x37","\x62\x6F\x64\x79","\u202E\x32\x38","\u202E\x32\x39","\x6F\x28\x56\x57","\u202E\x32\x62","\u202B\x32\x61","\x48\x67\x61\x66","\x4F\x51\x51\x30","\u202E\x32\x64","\x48\x48\x53\x76","\u202B\x32\x63","\x41\x73\x64\x5D","\u202E\x32\x65","\u202B\x32\x66","\x68\x59\x49\x71","\x70\x6F\x73\x74","\u202E\x33\x30","\u202E\x33\x31","\x61\x70\x69\x2E\x6D\x2E\x6A\x64\x2E\x63\x6F\x6D","\x51\x4F\x4F\x30\x30","\u202E\x33\x32","\u202B\x33\x33","\x4F\x4F\x30\x30\x30","\u202E\x33\x34","\u202B\x33\x35","\x5D\x63\x38\x74","\x51\x51\x30\x51","\x51\x51\x4F\x30\x4F","\x4F\x51\x4F\x4F","\u202B\x33\x38","\u202B\x33\x39","\x79\x40\x4D\x4F","\u202B\x33\x37","\u202E\x33\x61","\x26\x23\x6D\x5E","\u202B\x33\x62","\x4F\x4F\x30\x30\x4F","\u202E\x33\x63","\x55\x5A\x53\x26","\u202E\x33\x64","\x4E\x4D\x6B\x33","\u202E\x33\x65","\x30","\x51\x30\x30\x30","\u202B\x33\x66","\x4E\x75\x5A\x49","\u202B\x34\x30","\u202B\x34\x31","\u202B\x34\x33","\u202B\x34\x34","\u202B\x34\x32","\x51\x30\x30\x4F","\u202B\x34\x35","\u202B\x34\x36","\u202B\x34\x37","\u202B\x34\x39","\u202B\x34\x61","\u202B\x34\x38","\u202B\x34\x62","\u202B\x34\x63","\x66\x50\x38\x54","\u202E\x34\x64","\x59\x6A\x73\x77","\x51\x51\x4F\x51","\u202B\x34\x65","\x51\x4F\x4F\x4F\x4F","\u202E\x34\x66","\u202B\x35\x31","\u202B\x35\x30","\x51\x30\x51\x4F\x51","\u202E\x35\x33","\u202E\x35\x32","\u202B\x35\x34","\u202E\x33\x36","\u5220\u9664","\u7248\u672C\u53F7\uFF0C\x6A\x73\u4F1A\u5B9A","\u671F\u5F39\u7A97\uFF0C","\u8FD8\u8BF7\u652F\u6301\u6211\u4EEC\u7684\u5DE5\u4F5C","\x6A\x73\x6A\x69\x61","\x6D\x69\x2E\x63\x6F\x6D"];var OＯ0$=__Oxe874c[0x0],OＯ0$_=[__Oxe874c[0x1]],O00O=[OＯ0$,__Oxe874c[0x2],__Oxe874c[0x3],__Oxe874c[0x4],__Oxe874c[0x5],__Oxe874c[0x6],__Oxe874c[0x7],__Oxe874c[0x8],__Oxe874c[0x9],__Oxe874c[0xa],__Oxe874c[0xb],__Oxe874c[0xc],__Oxe874c[0xd],__Oxe874c[0xe],__Oxe874c[0xf],__Oxe874c[0x10],__Oxe874c[0x11],__Oxe874c[0x12],__Oxe874c[0x13],__Oxe874c[0x14],__Oxe874c[0x15],__Oxe874c[0x16],__Oxe874c[0x17],__Oxe874c[0x18],__Oxe874c[0x19],__Oxe874c[0x1a],__Oxe874c[0x1b],__Oxe874c[0x1c],__Oxe874c[0x1d],__Oxe874c[0x1e],__Oxe874c[0x1f],__Oxe874c[0x20],__Oxe874c[0x21],__Oxe874c[0x22],__Oxe874c[0x23],__Oxe874c[0x24],__Oxe874c[0x25],__Oxe874c[0x26],__Oxe874c[0x27],__Oxe874c[0x28],__Oxe874c[0x29],__Oxe874c[0x2a],__Oxe874c[0x2b],__Oxe874c[0x2c],__Oxe874c[0x2d],__Oxe874c[0x2e],__Oxe874c[0x2f],__Oxe874c[0x30],__Oxe874c[0x31],__Oxe874c[0x32],__Oxe874c[0x33],__Oxe874c[0x34],__Oxe874c[0x35],__Oxe874c[0x36],__Oxe874c[0x37],__Oxe874c[0x38],__Oxe874c[0x39],__Oxe874c[0x3a],__Oxe874c[0x3b],__Oxe874c[0x3c],__Oxe874c[0x3d],__Oxe874c[0x3e],__Oxe874c[0x3f],__Oxe874c[0x40],__Oxe874c[0x41],__Oxe874c[0x42],__Oxe874c[0x43],__Oxe874c[0x44],__Oxe874c[0x45],__Oxe874c[0x46],__Oxe874c[0x47],__Oxe874c[0x48],__Oxe874c[0x49],__Oxe874c[0x4a],__Oxe874c[0x4b],__Oxe874c[0x4c],__Oxe874c[0x4d],__Oxe874c[0x4e],__Oxe874c[0x4f],__Oxe874c[0x50],__Oxe874c[0x51],__Oxe874c[0x52],__Oxe874c[0x53],__Oxe874c[0x54],__Oxe874c[0x55],__Oxe874c[0x56],__Oxe874c[0x57]];if(function(_0x3ff2x4,_0x3ff2x5,_0x3ff2x6){function _0x3ff2x7(_0x3ff2x8,_0x3ff2x9,_0x3ff2xa,_0x3ff2xb,_0x3ff2xc,_0x3ff2xd){_0x3ff2x9= _0x3ff2x9>> 0x8,_0x3ff2xc= __Oxe874c[0x58];var _0x3ff2xe=__Oxe874c[0x59],_0x3ff2xf=__Oxe874c[0x5a],_0x3ff2xd=__Oxe874c[0x5b];if(_0x3ff2x9< _0x3ff2x8){while(--_0x3ff2x8){_0x3ff2xb= _0x3ff2x4[_0x3ff2xe]();if(_0x3ff2x9=== _0x3ff2x8&& _0x3ff2xd=== __Oxe874c[0x5b]&& _0x3ff2xd[__Oxe874c[0x5c]]=== 0x1){_0x3ff2x9= _0x3ff2xb,_0x3ff2xa= _0x3ff2x4[_0x3ff2xc+ __Oxe874c[0x5d]]()}else {if(_0x3ff2x9&& _0x3ff2xa[__Oxe874c[0x5f]](/[SlxhRGEUfTnCkD=]/g,__Oxe874c[0x5e])=== _0x3ff2x9){_0x3ff2x4[_0x3ff2xf](_0x3ff2xb)}}};_0x3ff2x4[_0x3ff2xf](_0x3ff2x4[_0x3ff2xe]())};return 0xfd240}return _0x3ff2x7(++_0x3ff2x5,_0x3ff2x6) >> _0x3ff2x5 ^ _0x3ff2x6}(O00O,0xea,0xea00),O00O){OＯ0$_= O00O[__Oxe874c[0x5c]]^ 0xea};function O0QQ(_0x3ff2x11,_0x3ff2x12){_0x3ff2x11=  ~~__Oxe874c[0x62][__Oxe874c[0x61]](_0x3ff2x11[__Oxe874c[0x60]](0x1));var _0x3ff2x13=O00O[_0x3ff2x11];if(O0QQ[__Oxe874c[0x63]]=== undefined){(function(){var _0x3ff2x14= typeof window!== __Oxe874c[0x64]?window: typeof process=== __Oxe874c[0x65]&&  typeof require=== __Oxe874c[0x66]&&  typeof global=== __Oxe874c[0x65]?global:this;var _0x3ff2x15=__Oxe874c[0x67];_0x3ff2x14[__Oxe874c[0x68]]|| (_0x3ff2x14[__Oxe874c[0x68]]= function(_0x3ff2x16){var _0x3ff2x17=String(_0x3ff2x16)[__Oxe874c[0x5f]](/=+$/,__Oxe874c[0x5e]);for(var _0x3ff2x18=0x0,_0x3ff2x19,_0x3ff2x1a,_0x3ff2x1b=0x0,_0x3ff2x1c=__Oxe874c[0x5e];_0x3ff2x1a= _0x3ff2x17[__Oxe874c[0x69]](_0x3ff2x1b++);~_0x3ff2x1a&& (_0x3ff2x19= _0x3ff2x18% 0x4?_0x3ff2x19* 0x40+ _0x3ff2x1a:_0x3ff2x1a,_0x3ff2x18++ % 0x4)?_0x3ff2x1c+= String[__Oxe874c[0x6a]](0xff& _0x3ff2x19>> (-0x2* _0x3ff2x18 & 0x6)):0x0){_0x3ff2x1a= _0x3ff2x15[__Oxe874c[0x6b]](_0x3ff2x1a)};return _0x3ff2x1c})}());function _0x3ff2x1d(_0x3ff2x1e,_0x3ff2x12){var _0x3ff2x1f=[],_0x3ff2x20=0x0,_0x3ff2x21,_0x3ff2x22=__Oxe874c[0x5e],_0x3ff2x23=__Oxe874c[0x5e];_0x3ff2x1e= atob(_0x3ff2x1e);for(var _0x3ff2x24=0x0,_0x3ff2x25=_0x3ff2x1e[__Oxe874c[0x5c]];_0x3ff2x24< _0x3ff2x25;_0x3ff2x24++){_0x3ff2x23+= __Oxe874c[0x6c]+ (__Oxe874c[0x6d]+ _0x3ff2x1e[__Oxe874c[0x6f]](_0x3ff2x24)[__Oxe874c[0x6e]](0x10))[__Oxe874c[0x60]](-0x2)};_0x3ff2x1e= decodeURIComponent(_0x3ff2x23);for(var _0x3ff2x26=0x0;_0x3ff2x26< 0x100;_0x3ff2x26++){_0x3ff2x1f[_0x3ff2x26]= _0x3ff2x26};for(_0x3ff2x26= 0x0;_0x3ff2x26< 0x100;_0x3ff2x26++){_0x3ff2x20= (_0x3ff2x20+ _0x3ff2x1f[_0x3ff2x26]+ _0x3ff2x12[__Oxe874c[0x6f]](_0x3ff2x26% _0x3ff2x12[__Oxe874c[0x5c]]))% 0x100;_0x3ff2x21= _0x3ff2x1f[_0x3ff2x26];_0x3ff2x1f[_0x3ff2x26]= _0x3ff2x1f[_0x3ff2x20];_0x3ff2x1f[_0x3ff2x20]= _0x3ff2x21};_0x3ff2x26= 0x0;_0x3ff2x20= 0x0;for(var _0x3ff2x27=0x0;_0x3ff2x27< _0x3ff2x1e[__Oxe874c[0x5c]];_0x3ff2x27++){_0x3ff2x26= (_0x3ff2x26+ 0x1)% 0x100;_0x3ff2x20= (_0x3ff2x20+ _0x3ff2x1f[_0x3ff2x26])% 0x100;_0x3ff2x21= _0x3ff2x1f[_0x3ff2x26];_0x3ff2x1f[_0x3ff2x26]= _0x3ff2x1f[_0x3ff2x20];_0x3ff2x1f[_0x3ff2x20]= _0x3ff2x21;_0x3ff2x22+= String[__Oxe874c[0x6a]](_0x3ff2x1e[__Oxe874c[0x6f]](_0x3ff2x27)^ _0x3ff2x1f[(_0x3ff2x1f[_0x3ff2x26]+ _0x3ff2x1f[_0x3ff2x20])% 0x100])};return _0x3ff2x22}O0QQ[__Oxe874c[0x70]]= _0x3ff2x1d;O0QQ[__Oxe874c[0x71]]= {};O0QQ[__Oxe874c[0x63]]=  !![]};var _0x3ff2x28=O0QQ[__Oxe874c[0x71]][_0x3ff2x11];if(_0x3ff2x28=== undefined){if(O0QQ[__Oxe874c[0x72]]=== undefined){O0QQ[__Oxe874c[0x72]]=  !![]};_0x3ff2x13= O0QQ[__Oxe874c[0x70]](_0x3ff2x13,_0x3ff2x12);O0QQ[__Oxe874c[0x71]][_0x3ff2x11]= _0x3ff2x13}else {_0x3ff2x13= _0x3ff2x28};return _0x3ff2x13}const API=process[__Oxe874c[0x75]][O0QQ(__Oxe874c[0x73],__Oxe874c[0x74])]|| O0QQ(__Oxe874c[0x76],__Oxe874c[0x77]);async function getToken(_0x3ff2x2b,_0x3ff2x2c){var _0x3ff2x2d={'\x51\x4F\x4F\x4F':function(_0x3ff2x2e,_0x3ff2x2f){return _0x3ff2x2e+ _0x3ff2x2f},'\x4F\x4F\x30\x4F':O0QQ(__Oxe874c[0x78],__Oxe874c[0x79]),'\x4F\x4F\x51\x4F':function(_0x3ff2x30,_0x3ff2x31){return _0x3ff2x30=== _0x3ff2x31},'\x4F\x51\x4F\x51':__Oxe874c[0x65],'\x4F\x4F\x4F\x4F':O0QQ(__Oxe874c[0x7a],__Oxe874c[0x7b]),'\x51\x51\x51\x51':O0QQ(__Oxe874c[0x7c],__Oxe874c[0x7d]),'\x4F\x30\x4F\x30':__Oxe874c[0x7e],'\x51\x51\x30\x51':function(_0x3ff2x32,_0x3ff2x33){return _0x3ff2x32(_0x3ff2x33)},'\x4F\x51\x4F\x4F':function(_0x3ff2x34,_0x3ff2x35){return _0x3ff2x34=== _0x3ff2x35},'\x4F\x4F\x4F\x51':__Oxe874c[0x7f],'\x4F\x4F\x4F\x4F\x30':O0QQ(__Oxe874c[0x80],__Oxe874c[0x81]),'\x4F\x4F\x30\x30\x4F':function(_0x3ff2x36,_0x3ff2x37){return _0x3ff2x36!== _0x3ff2x37},'\x4F\x51\x4F\x30\x30':O0QQ(__Oxe874c[0x82],__Oxe874c[0x83]),'\x4F\x51\x4F\x51\x30':__Oxe874c[0x84],'\x4F\x4F\x30\x51\x4F':O0QQ(__Oxe874c[0x85],__Oxe874c[0x86]),'\x51\x51\x4F\x51\x51':__Oxe874c[0x87],'\x51\x51\x4F\x30\x4F':O0QQ(__Oxe874c[0x88],__Oxe874c[0x89]),'\x51\x51\x4F\x51\x4F':O0QQ(__Oxe874c[0x8a],__Oxe874c[0x8b]),'\x51\x30\x51\x4F\x51':__Oxe874c[0x8c],'\x51\x30\x30\x4F\x30':O0QQ(__Oxe874c[0x8d],__Oxe874c[0x8e]),'\x51\x4F\x4F\x51\x30':O0QQ(__Oxe874c[0x8f],__Oxe874c[0x83]),'\x51\x4F\x4F\x30\x30':O0QQ(__Oxe874c[0x90],__Oxe874c[0x91]),'\x4F\x4F\x51\x30\x51':O0QQ(__Oxe874c[0x92],__Oxe874c[0x8e]),'\x4F\x4F\x30\x30\x30':O0QQ(__Oxe874c[0x93],__Oxe874c[0x7d]),'\x4F\x4F\x51\x30\x4F':O0QQ(__Oxe874c[0x94],__Oxe874c[0x95])};function _0x3ff2x38(_0x3ff2x39,_0x3ff2x3a){var _0x3ff2x3b={'\x51\x4F\x4F\x51':function(_0x3ff2x3c,_0x3ff2x3d){return _0x3ff2x3c(_0x3ff2x3d)},'\x4F\x51\x51\x51':function(_0x3ff2x3e,_0x3ff2x3f){return _0x3ff2x3e=== _0x3ff2x3f},'\x51\x4F\x30\x30':function(_0x3ff2x40,_0x3ff2x41){return _0x3ff2x2d[O0QQ(__Oxe874c[0x96],__Oxe874c[0x97])](_0x3ff2x40,_0x3ff2x41)},'\x51\x51\x51\x30':_0x3ff2x2d[O0QQ(__Oxe874c[0x98],__Oxe874c[0x99])],'\x51\x30\x4F\x4F':function(_0x3ff2x42,_0x3ff2x43){return _0x3ff2x2d[__Oxe874c[0x9a]](_0x3ff2x42,_0x3ff2x43)},'\x51\x4F\x51\x30':_0x3ff2x2d[O0QQ(__Oxe874c[0x9b],__Oxe874c[0x9c])],'\x4F\x30\x51\x4F':_0x3ff2x2d[__Oxe874c[0x9d]],'\x4F\x51\x51\x30':_0x3ff2x2d[O0QQ(__Oxe874c[0x9e],__Oxe874c[0x9f])],'\x51\x30\x30\x51':_0x3ff2x2d[O0QQ(__Oxe874c[0xa0],__Oxe874c[0xa1])],'\x4F\x4F\x30\x30':function(_0x3ff2x44,_0x3ff2x45){return _0x3ff2x2d[O0QQ(__Oxe874c[0xa2],__Oxe874c[0xa3])](_0x3ff2x44,_0x3ff2x45)},'\x4F\x51\x30\x30':function(_0x3ff2x46,_0x3ff2x47){return _0x3ff2x2d[O0QQ(__Oxe874c[0xa4],__Oxe874c[0xa5])](_0x3ff2x46,_0x3ff2x47)},'\x4F\x30\x4F\x51':_0x3ff2x2d[O0QQ(__Oxe874c[0xa6],__Oxe874c[0xa7])]};let _0x3ff2x48={'\x66\x6E':_0x3ff2x39,'\x62\x6F\x64\x79':JSON[O0QQ(__Oxe874c[0xa8],__Oxe874c[0xa5])](_0x3ff2x3a)};let _0x3ff2x49={'\x75\x72\x6C':API,'\x62\x6F\x64\x79':JSON[O0QQ(__Oxe874c[0xa9],__Oxe874c[0x95])](_0x3ff2x48),'\x68\x65\x61\x64\x65\x72\x73':{'\x43\x6F\x6E\x74\x65\x6E\x74\x2D\x54\x79\x70\x65':__Oxe874c[0xaa]},'\x74\x69\x6D\x65\x6F\x75\x74':0x7530};return  new Promise(async (_0x3ff2x4a)=>{if(_0x3ff2x3b[O0QQ(__Oxe874c[0xae],__Oxe874c[0x91])](_0x3ff2x3b[O0QQ(__Oxe874c[0xab],__Oxe874c[0x74])],O0QQ(__Oxe874c[0xac],__Oxe874c[0xad]))){console[O0QQ(__Oxe874c[0xb0],__Oxe874c[0x74])](O0QQ(__Oxe874c[0xaf],__Oxe874c[0x99]))}else {$[__Oxe874c[0xd1]](_0x3ff2x49,(_0x3ff2x4b,_0x3ff2x4c,_0x3ff2x48)=>{var _0x3ff2x4d={'\x4F\x51\x30\x51':function(_0x3ff2x4e,_0x3ff2x4f){return _0x3ff2x3b[O0QQ(__Oxe874c[0xb1],__Oxe874c[0x99])](_0x3ff2x4e,_0x3ff2x4f)}};try{if(_0x3ff2x4b){if(_0x3ff2x3b[O0QQ(__Oxe874c[0xb6],__Oxe874c[0xb7])](O0QQ(__Oxe874c[0xb2],__Oxe874c[0xb3]),O0QQ(__Oxe874c[0xb4],__Oxe874c[0xb5]))){console[__Oxe874c[0xbb]](_0x3ff2x3b[O0QQ(__Oxe874c[0xba],__Oxe874c[0x86])](__Oxe874c[0x5e],JSON[O0QQ(__Oxe874c[0xb8],__Oxe874c[0xb9])](_0x3ff2x4b)));console[__Oxe874c[0xbb]](_0x3ff2x3b[__Oxe874c[0xbc]])}else {$[__Oxe874c[0xbd]](e,_0x3ff2x4c)}}else {_0x3ff2x48= JSON[__Oxe874c[0xbe]](_0x3ff2x48);if(_0x3ff2x3b[O0QQ(__Oxe874c[0xc0],__Oxe874c[0x81])]( typeof _0x3ff2x48,_0x3ff2x3b[O0QQ(__Oxe874c[0xbf],__Oxe874c[0x79])])&& _0x3ff2x48&& _0x3ff2x48[O0QQ(__Oxe874c[0xc1],__Oxe874c[0x89])]){if(_0x3ff2x48[__Oxe874c[0xc2]]){$[O0QQ(__Oxe874c[0xc3],__Oxe874c[0xa7])]= _0x3ff2x48[O0QQ(__Oxe874c[0xc4],__Oxe874c[0xc5])]|| __Oxe874c[0x5e]}}else {console[O0QQ(__Oxe874c[0xc7],__Oxe874c[0xc8])](_0x3ff2x3b[O0QQ(__Oxe874c[0xc6],__Oxe874c[0x89])])}}}catch(QQ0OO){if(_0x3ff2x3b[O0QQ(__Oxe874c[0xcc],__Oxe874c[0xcd])](_0x3ff2x3b[__Oxe874c[0xc9]],_0x3ff2x3b[O0QQ(__Oxe874c[0xca],__Oxe874c[0xcb])])){_0x3ff2x4d[O0QQ(__Oxe874c[0xce],__Oxe874c[0xa1])](_0x3ff2x4a,_0x3ff2x50)}else {$[__Oxe874c[0xbd]](QQ0OO,_0x3ff2x4c)}}finally{_0x3ff2x3b[O0QQ(__Oxe874c[0xcf],__Oxe874c[0xd0])](_0x3ff2x4a,_0x3ff2x48)}})}})} await _0x3ff2x38(O0QQ(__Oxe874c[0xd2],__Oxe874c[0x81]),{'\x69\x64':__Oxe874c[0x5e],'\x75\x72\x6C':_0x3ff2x2c});let _0x3ff2x50=null;let _0x3ff2x51={'\x75\x72\x6C':_0x3ff2x2d[O0QQ(__Oxe874c[0xd3],__Oxe874c[0xcd])],'\x68\x65\x61\x64\x65\x72\x73':{'\x48\x6F\x73\x74':__Oxe874c[0xd4],'\x43\x6F\x6E\x74\x65\x6E\x74\x2D\x54\x79\x70\x65':_0x3ff2x2d[__Oxe874c[0xd5]],'\x41\x63\x63\x65\x70\x74':_0x3ff2x2d[O0QQ(__Oxe874c[0xd6],__Oxe874c[0xb3])],'\x43\x6F\x6E\x6E\x65\x63\x74\x69\x6F\x6E':O0QQ(__Oxe874c[0xd7],__Oxe874c[0xa1]),'\x43\x6F\x6F\x6B\x69\x65':_0x3ff2x2b,'\x55\x73\x65\x72\x2D\x41\x67\x65\x6E\x74':_0x3ff2x2d[__Oxe874c[0xd8]],'\x41\x63\x63\x65\x70\x74\x2D\x4C\x61\x6E\x67\x75\x61\x67\x65':O0QQ(__Oxe874c[0xd9],__Oxe874c[0x7b]),'\x41\x63\x63\x65\x70\x74\x2D\x45\x6E\x63\x6F\x64\x69\x6E\x67':_0x3ff2x2d[O0QQ(__Oxe874c[0xda],__Oxe874c[0xdb])]},'\x62\x6F\x64\x79':__Oxe874c[0x5e]+ $[O0QQ(__Oxe874c[0xc3],__Oxe874c[0xa7])]};return  new Promise((_0x3ff2x52)=>{var _0x3ff2x53={'\x51\x4F\x4F\x30':function(_0x3ff2x54,_0x3ff2x55){return _0x3ff2x2d[__Oxe874c[0xdc]](_0x3ff2x54,_0x3ff2x55)},'\x51\x30\x30\x4F':_0x3ff2x2d[__Oxe874c[0xdd]],'\x51\x4F\x4F\x4F\x4F':function(_0x3ff2x56,_0x3ff2x57){return _0x3ff2x2d[__Oxe874c[0xde]](_0x3ff2x56,_0x3ff2x57)}};$[O0QQ(__Oxe874c[0x10b],__Oxe874c[0x97])](_0x3ff2x51,(_0x3ff2x58,_0x3ff2x59,_0x3ff2x5a)=>{try{if(_0x3ff2x2d[O0QQ(__Oxe874c[0xe2],__Oxe874c[0xb7])](_0x3ff2x2d[O0QQ(__Oxe874c[0xdf],__Oxe874c[0xa7])],_0x3ff2x2d[O0QQ(__Oxe874c[0xe0],__Oxe874c[0xe1])])){if(_0x3ff2x58){if(_0x3ff2x2d[__Oxe874c[0xe6]](_0x3ff2x2d[O0QQ(__Oxe874c[0xe3],__Oxe874c[0xe4])],_0x3ff2x2d[O0QQ(__Oxe874c[0xe5],__Oxe874c[0x74])])){$[O0QQ(__Oxe874c[0xe7],__Oxe874c[0xe8])](_0x3ff2x58)}else {_0x3ff2x53[O0QQ(__Oxe874c[0xe9],__Oxe874c[0xea])](_0x3ff2x52,__Oxe874c[0x5e])}}else {if(_0x3ff2x5a){_0x3ff2x5a= JSON[__Oxe874c[0xbe]](_0x3ff2x5a);if(_0x3ff2x5a[O0QQ(__Oxe874c[0xeb],__Oxe874c[0x79])]=== __Oxe874c[0xec]){if(_0x3ff2x2d[__Oxe874c[0xde]](__Oxe874c[0xed],_0x3ff2x2d[O0QQ(__Oxe874c[0xee],__Oxe874c[0xef])])){_0x3ff2x50= _0x3ff2x5a[O0QQ(__Oxe874c[0xf0],__Oxe874c[0x74])]}else {_0x3ff2x50= _0x3ff2x5a[O0QQ(__Oxe874c[0xf1],__Oxe874c[0x95])]}}}else {if(_0x3ff2x2d[O0QQ(__Oxe874c[0xf4],__Oxe874c[0xd0])](_0x3ff2x2d[O0QQ(__Oxe874c[0xf2],__Oxe874c[0x95])],_0x3ff2x2d[O0QQ(__Oxe874c[0xf3],__Oxe874c[0xb9])])){$[O0QQ(__Oxe874c[0xf6],__Oxe874c[0xa5])](_0x3ff2x53[__Oxe874c[0xf5]])}else {$[O0QQ(__Oxe874c[0xf6],__Oxe874c[0xa5])](_0x3ff2x2d[O0QQ(__Oxe874c[0xf7],__Oxe874c[0x8e])])}}}}else {_0x3ff2x53[O0QQ(__Oxe874c[0xf8],__Oxe874c[0xb5])](_0x3ff2x52,_0x3ff2x5a)}}catch(O0OOO){if(_0x3ff2x2d[O0QQ(__Oxe874c[0xfb],__Oxe874c[0x79])](_0x3ff2x2d[O0QQ(__Oxe874c[0xf9],__Oxe874c[0x74])],O0QQ(__Oxe874c[0xfa],__Oxe874c[0xe8]))){if(_0x3ff2x5a[__Oxe874c[0xc2]]){$[O0QQ(__Oxe874c[0xfc],__Oxe874c[0x7b])]= _0x3ff2x5a[O0QQ(__Oxe874c[0xfd],__Oxe874c[0xfe])]|| __Oxe874c[0x5e]}}else {$[O0QQ(__Oxe874c[0xff],__Oxe874c[0x100])](O0OOO)}}finally{if(_0x3ff2x50){if(__Oxe874c[0x101]!== O0QQ(__Oxe874c[0x102],__Oxe874c[0xe4])){_0x3ff2x2d[__Oxe874c[0xdc]](_0x3ff2x52,_0x3ff2x50)}else {if(_0x3ff2x5a){_0x3ff2x5a= JSON[__Oxe874c[0xbe]](_0x3ff2x5a);if(_0x3ff2x53[__Oxe874c[0x103]](_0x3ff2x5a[O0QQ(__Oxe874c[0xeb],__Oxe874c[0x79])],__Oxe874c[0xec])){_0x3ff2x50= _0x3ff2x5a[O0QQ(__Oxe874c[0x104],__Oxe874c[0x100])]}}else {$[O0QQ(__Oxe874c[0x106],__Oxe874c[0xc5])](O0QQ(__Oxe874c[0x105],__Oxe874c[0xb7]))}}}else {if(_0x3ff2x2d[O0QQ(__Oxe874c[0x109],__Oxe874c[0xdb])](_0x3ff2x2d[__Oxe874c[0x107]],_0x3ff2x2d[O0QQ(__Oxe874c[0x108],__Oxe874c[0x8e])])){$[O0QQ(__Oxe874c[0x10a],__Oxe874c[0xdb])](error)}else {_0x3ff2x2d[__Oxe874c[0xdc]](_0x3ff2x52,__Oxe874c[0x5e])}}}})})};;OＯ0$= __Oxe874c[0x0];;;(function(_0x3ff2x5b,_0x3ff2x5c,_0x3ff2x5d,_0x3ff2x5e,_0x3ff2x5f,_0x3ff2x60){_0x3ff2x60= __Oxe874c[0x64];_0x3ff2x5e= function(_0x3ff2x61){if( typeof alert!== _0x3ff2x60){alert(_0x3ff2x61)};if( typeof console!== _0x3ff2x60){console[__Oxe874c[0xbb]](_0x3ff2x61)}};_0x3ff2x5d= function(_0x3ff2x62,_0x3ff2x5b){return _0x3ff2x62+ _0x3ff2x5b};_0x3ff2x5f= _0x3ff2x5d(__Oxe874c[0x10c],_0x3ff2x5d(_0x3ff2x5d(__Oxe874c[0x10d],__Oxe874c[0x10e]),__Oxe874c[0x10f]));try{_0x3ff2x5b= __encode;if(!( typeof _0x3ff2x5b!== _0x3ff2x60&& _0x3ff2x5b=== _0x3ff2x5d(__Oxe874c[0x110],__Oxe874c[0x111]))){_0x3ff2x5e(_0x3ff2x5f)}}catch(e){_0x3ff2x5e(_0x3ff2x5f)}})({})

function Env(t, e) {
    "undefined" != typeof process && JSON.stringify(process.env).indexOf("GITHUB") > -1 && process.exit(0);
    class s {
        constructor(t) {
            this.env = t
        }
        send(t, e = "GET") {
            t = "string" == typeof t ? {
                url: t
            } : t;
            let s = this.get;
            return "POST" === e && (s = this.post), new Promise((e, i) => {
                s.call(this, t, (t, s, r) => {
                    t ? i(t) : e(s)
                })
            })
        }
        get(t) {
            return this.send.call(this.env, t)
        }
        post(t) {
            return this.send.call(this.env, t, "POST")
        }
    }
    return new class {
        constructor(t, e) {
            this.name = t, this.http = new s(this), this.data = null, this.dataFile = "box.dat", this.logs = [], this.isMute = !1, this.isNeedRewrite = !1, this.logSeparator = "\n", this.startTime = (new Date).getTime(), Object.assign(this, e)
        }
        isNode() {
            return "undefined" != typeof module && !!module.exports
        }
        isQuanX() {
            return "undefined" != typeof $task
        }
        isSurge() {
            return "undefined" != typeof $httpClient && "undefined" == typeof $loon
        }
        isLoon() {
            return "undefined" != typeof $loon
        }
        toObj(t, e = null) {
            try {
                return JSON.parse(t)
            } catch {
                return e
            }
        }
        toStr(t, e = null) {
            try {
                return JSON.stringify(t)
            } catch {
                return e
            }
        }
        getjson(t, e) {
            let s = e;
            const i = this.getdata(t);
            if (i) try {
                s = JSON.parse(this.getdata(t))
            } catch {}
            return s
        }
        setjson(t, e) {
            try {
                return this.setdata(JSON.stringify(t), e)
            } catch {
                return !1
            }
        }
        getScript(t) {
            return new Promise(e => {
                this.get({
                    url: t
                }, (t, s, i) => e(i))
            })
        }
        runScript(t, e) {
            return new Promise(s => {
                let i = this.getdata("@chavy_boxjs_userCfgs.httpapi");
                i = i ? i.replace(/\n/g, "").trim() : i;
                let r = this.getdata("@chavy_boxjs_userCfgs.httpapi_timeout");
                r = r ? 1 * r : 20, r = e && e.timeout ? e.timeout : r;
                const [o, h] = i.split("@"), n = {
                    url: `http://${h}/v1/scripting/evaluate`,
                    body: {
                        script_text: t,
                        mock_type: "cron",
                        timeout: r
                    },
                    headers: {
                        "X-Key": o,
                        Accept: "*/*"
                    }
                };
                this.post(n, (t, e, i) => s(i))
            }).catch(t => this.logErr(t))
        }
        loaddata() {
            if (!this.isNode()) return {}; {
                this.fs = this.fs ? this.fs : require("fs"), this.path = this.path ? this.path : require("path");
                const t = this.path.resolve(this.dataFile),
                    e = this.path.resolve(process.cwd(), this.dataFile),
                    s = this.fs.existsSync(t),
                    i = !s && this.fs.existsSync(e);
                if (!s && !i) return {}; {
                    const i = s ? t : e;
                    try {
                        return JSON.parse(this.fs.readFileSync(i))
                    } catch (t) {
                        return {}
                    }
                }
            }
        }
        writedata() {
            if (this.isNode()) {
                this.fs = this.fs ? this.fs : require("fs"), this.path = this.path ? this.path : require("path");
                const t = this.path.resolve(this.dataFile),
                    e = this.path.resolve(process.cwd(), this.dataFile),
                    s = this.fs.existsSync(t),
                    i = !s && this.fs.existsSync(e),
                    r = JSON.stringify(this.data);
                s ? this.fs.writeFileSync(t, r) : i ? this.fs.writeFileSync(e, r) : this.fs.writeFileSync(t, r)
            }
        }
        lodash_get(t, e, s) {
            const i = e.replace(/\[(\d+)\]/g, ".$1").split(".");
            let r = t;
            for (const t of i)
                if (r = Object(r)[t], void 0 === r) return s;
            return r
        }
        lodash_set(t, e, s) {
            return Object(t) !== t ? t : (Array.isArray(e) || (e = e.toString().match(/[^.[\]]+/g) || []), e.slice(0, -1).reduce((t, s, i) => Object(t[s]) === t[s] ? t[s] : t[s] = Math.abs(e[i + 1]) >> 0 == +e[i + 1] ? [] : {}, t)[e[e.length - 1]] = s, t)
        }
        getdata(t) {
            let e = this.getval(t);
            if (/^@/.test(t)) {
                const [, s, i] = /^@(.*?)\.(.*?)$/.exec(t), r = s ? this.getval(s) : "";
                if (r) try {
                    const t = JSON.parse(r);
                    e = t ? this.lodash_get(t, i, "") : e
                } catch (t) {
                    e = ""
                }
            }
            return e
        }
        setdata(t, e) {
            let s = !1;
            if (/^@/.test(e)) {
                const [, i, r] = /^@(.*?)\.(.*?)$/.exec(e), o = this.getval(i), h = i ? "null" === o ? null : o || "{}" : "{}";
                try {
                    const e = JSON.parse(h);
                    this.lodash_set(e, r, t), s = this.setval(JSON.stringify(e), i)
                } catch (e) {
                    const o = {};
                    this.lodash_set(o, r, t), s = this.setval(JSON.stringify(o), i)
                }
            } else s = this.setval(t, e);
            return s
        }
        getval(t) {
            return this.isSurge() || this.isLoon() ? $persistentStore.read(t) : this.isQuanX() ? $prefs.valueForKey(t) : this.isNode() ? (this.data = this.loaddata(), this.data[t]) : this.data && this.data[t] || null
        }
        setval(t, e) {
            return this.isSurge() || this.isLoon() ? $persistentStore.write(t, e) : this.isQuanX() ? $prefs.setValueForKey(t, e) : this.isNode() ? (this.data = this.loaddata(), this.data[e] = t, this.writedata(), !0) : this.data && this.data[e] || null
        }
        initGotEnv(t) {
            this.got = this.got ? this.got : require("got"), this.cktough = this.cktough ? this.cktough : require("tough-cookie"), this.ckjar = this.ckjar ? this.ckjar : new this.cktough.CookieJar, t && (t.headers = t.headers ? t.headers : {}, void 0 === t.headers.Cookie && void 0 === t.cookieJar && (t.cookieJar = this.ckjar))
        }
        get(t, e = (() => {})) {
            t.headers && (delete t.headers["Content-Type"], delete t.headers["Content-Length"]), this.isSurge() || this.isLoon() ? (this.isSurge() && this.isNeedRewrite && (t.headers = t.headers || {}, Object.assign(t.headers, {
                "X-Surge-Skip-Scripting": !1
            })), $httpClient.get(t, (t, s, i) => {
                !t && s && (s.body = i, s.statusCode = s.status), e(t, s, i)
            })) : this.isQuanX() ? (this.isNeedRewrite && (t.opts = t.opts || {}, Object.assign(t.opts, {
                hints: !1
            })), $task.fetch(t).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => e(t))) : this.isNode() && (this.initGotEnv(t), this.got(t).on("redirect", (t, e) => {
                try {
                    if (t.headers["set-cookie"]) {
                        const s = t.headers["set-cookie"].map(this.cktough.Cookie.parse).toString();
                        s && this.ckjar.setCookieSync(s, null), e.cookieJar = this.ckjar
                    }
                } catch (t) {
                    this.logErr(t)
                }
            }).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => {
                const {
                    message: s,
                    response: i
                } = t;
                e(s, i, i && i.body)
            }))
        }
        post(t, e = (() => {})) {
            if (t.body && t.headers && !t.headers["Content-Type"] && (t.headers["Content-Type"] = "application/x-www-form-urlencoded"), t.headers && delete t.headers["Content-Length"], this.isSurge() || this.isLoon()) this.isSurge() && this.isNeedRewrite && (t.headers = t.headers || {}, Object.assign(t.headers, {
                "X-Surge-Skip-Scripting": !1
            })), $httpClient.post(t, (t, s, i) => {
                !t && s && (s.body = i, s.statusCode = s.status), e(t, s, i)
            });
            else if (this.isQuanX()) t.method = "POST", this.isNeedRewrite && (t.opts = t.opts || {}, Object.assign(t.opts, {
                hints: !1
            })), $task.fetch(t).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => e(t));
            else if (this.isNode()) {
                this.initGotEnv(t);
                const {
                    url: s,
                    ...i
                } = t;
                this.got.post(s, i).then(t => {
                    const {
                        statusCode: s,
                        statusCode: i,
                        headers: r,
                        body: o
                    } = t;
                    e(null, {
                        status: s,
                        statusCode: i,
                        headers: r,
                        body: o
                    }, o)
                }, t => {
                    const {
                        message: s,
                        response: i
                    } = t;
                    e(s, i, i && i.body)
                })
            }
        }
        time(t, e = null) {
            const s = e ? new Date(e) : new Date;
            let i = {
                "M+": s.getMonth() + 1,
                "d+": s.getDate(),
                "H+": s.getHours(),
                "m+": s.getMinutes(),
                "s+": s.getSeconds(),
                "q+": Math.floor((s.getMonth() + 3) / 3),
                S: s.getMilliseconds()
            };
            /(y+)/.test(t) && (t = t.replace(RegExp.$1, (s.getFullYear() + "").substr(4 - RegExp.$1.length)));
            for (let e in i) new RegExp("(" + e + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? i[e] : ("00" + i[e]).substr(("" + i[e]).length)));
            return t
        }
        msg(e = t, s = "", i = "", r) {
            const o = t => {
                if (!t) return t;
                if ("string" == typeof t) return this.isLoon() ? t : this.isQuanX() ? {
                    "open-url": t
                } : this.isSurge() ? {
                    url: t
                } : void 0;
                if ("object" == typeof t) {
                    if (this.isLoon()) {
                        let e = t.openUrl || t.url || t["open-url"],
                            s = t.mediaUrl || t["media-url"];
                        return {
                            openUrl: e,
                            mediaUrl: s
                        }
                    }
                    if (this.isQuanX()) {
                        let e = t["open-url"] || t.url || t.openUrl,
                            s = t["media-url"] || t.mediaUrl;
                        return {
                            "open-url": e,
                            "media-url": s
                        }
                    }
                    if (this.isSurge()) {
                        let e = t.url || t.openUrl || t["open-url"];
                        return {
                            url: e
                        }
                    }
                }
            };
            if (this.isMute || (this.isSurge() || this.isLoon() ? $notification.post(e, s, i, o(r)) : this.isQuanX() && $notify(e, s, i, o(r))), !this.isMuteLog) {
                let t = ["", "==============📣系统通知📣=============="];
                t.push(e), s && t.push(s), i && t.push(i), console.log(t.join("\n")), this.logs = this.logs.concat(t)
            }
        }
        log(...t) {
            t.length > 0 && (this.logs = [...this.logs, ...t]), console.log(t.join(this.logSeparator))
        }
        logErr(t, e) {
            const s = !this.isSurge() && !this.isQuanX() && !this.isLoon();
            s ? this.log("", `❗️${this.name}, 错误!`, t.stack) : this.log("", `❗️${this.name}, 错误!`, t)
        }
        wait(t) {
            return new Promise(e => setTimeout(e, t))
        }
    }(t, e)
}

module.exports = getToken;
